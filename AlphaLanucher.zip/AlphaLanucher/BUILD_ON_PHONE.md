# Building AlphaLanucher using only an Android phone

No computer, and nothing needs to be installed beforehand. These steps are
untested by me: I could not compile the project or run an Android build in my
environment, so expect to fix small problems along the way.

## Method A (recommended): AndroidIDE, builds on the phone

AndroidIDE is a free app that builds real Gradle Android projects on Android.
Its documentation says projects must use Android Gradle Plugin 7.2.0 or newer
(this project uses 8.5.2).

Heads-up: the main AndroidIDE GitHub repository shows as archived (read-only)
since October 2024, so check its website (docs.androidide.com) for where the
current APK is offered. Only install it from the official site or the official
GitHub releases, never from random sites.

1. **Get the project onto your phone.** Download `AlphaLanucher.zip` from the
   chat. Open it with a file manager that can extract zips (for example the
   "Files" app) and extract it so you have a folder named `AlphaLanucher`.
2. **Install AndroidIDE.** Download its APK from the official source, open it,
   and when Android asks, allow "Install unknown apps" for your browser/file
   manager. Make sure the phone has several GB free and a Wi-Fi connection.
3. **First-time setup.** Open AndroidIDE, grant the permissions it asks for,
   and follow its setup to install the build tools (JDK 17 and the Android
   SDK). It runs a script called `idesetup` in its terminal for this. Pick SDK
   34 if asked.
   - If only an older SDK is available (say 33), edit `app/build.gradle` and
     change `compileSdk 34` and `targetSdk 34` to that number.
4. **Open the project.** In AndroidIDE choose the option to open a saved
   project/folder and select the `AlphaLanucher` folder. If it only lists
   projects in its own projects folder, copy `AlphaLanucher` there first.
5. **Wait for Gradle sync.** The first sync downloads Gradle 8.7 and the
   Android Gradle Plugin. This can take a long time on a phone. Keep the app
   open and the screen on.
6. **Build.** Use the Build / Run button (or build "assembleDebug"). When it
   finishes, the APK is at:
   `AlphaLanucher/app/build/outputs/apk/debug/app-debug.apk`
7. **Install it.** Tap the APK in your file manager and allow installing from
   this source. It's a debug build, signed automatically with a debug key. That's fine
   for personal use.

## Method B (backup): build in the cloud from your phone

Uses GitHub's free build servers via the included `.github/workflows/build.yml`.
You need a free GitHub account and the Termux app (from F-Droid) to upload the
folder, because phone browsers cannot upload nested folders.

1. In Termux: `pkg install git unzip` then `termux-setup-storage`.
2. Unzip the project, `cd` into it, then `git init`, `git add .`,
   `git commit -m "AlphaLanucher"`.
3. Create an empty repository on github.com in your phone browser, then in
   Termux add it as `origin` and `git push` (GitHub asks for a personal access
   token instead of a password).
4. On github.com open the repository's **Actions** tab, choose
   **Build AlphaLanucher APK**, and tap **Run workflow**.
5. When it turns green, open the run and download the
   `AlphaLanucher-debug-apk` artifact, extract the zip, and install the APK.

## Using it with Minecraft

AlphaLanucher contains no game files. You must install Minecraft PE 0.14.3 or
0.15.10 yourself, from a copy you legally own.

- Only **one** of the two versions can be installed at a time (same package
  name). The launcher will tell you which one it found.
- To change version: back up your worlds (they are usually in the
  `games/com.mojang` folder), uninstall the current version (Settings →
  "Open Minecraft app info" takes you to the right screen), install the other
  one, then reopen AlphaLanucher.
- These are very old game builds. Whether they run on a newer phone or Android
  version depends on the game, not the launcher.

## If the build fails

- "SDK location not found" / missing platform: change `compileSdk` and
  `targetSdk` to the SDK version AndroidIDE installed.
- "Unsupported Java version": make sure AndroidIDE is using JDK 17.
- Plugin/Gradle download errors: check your connection and retry the sync.
- Paste the error text into the chat and I can help fix it.
