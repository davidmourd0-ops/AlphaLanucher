# AlphaLanucher — Architecture

AlphaLanucher is a native Android app (Java, no third-party libraries) that
detects whether Minecraft PE 0.14.3 or 0.15.10 is installed and starts it.

**Status:** source code only. This project has NOT been compiled into an APK
yet. The version-matching logic was unit-checked in isolation; the Android
build and UI have not been run on a device.

## What it does / does not do

| Does | Does not |
|------|----------|
| Reads the installed Minecraft version through Android's PackageManager | Include, download, patch or redistribute any Minecraft files |
| Highlights the selected version and shows install state per card | Switch between versions |
| Starts the installed game with its normal launch intent | Run two versions side by side |

Why it cannot switch versions: both supported versions use the same Android
package name, `com.mojang.minecraftpe`. Android allows one app per package
name, so only one version can be installed at a time. Changing version means
uninstalling the current one and installing the other yourself, from a copy
you legally own. (Back up your worlds first.)

## Project tree

```
AlphaLanucher/
├── settings.gradle            project name + repositories
├── build.gradle               Android Gradle Plugin 8.5.2
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties   Gradle 8.7
├── .github/workflows/build.yml                optional cloud build
└── app/
    ├── build.gradle           compileSdk 34, minSdk 23, no dependencies
    └── src/main/
        ├── AndroidManifest.xml    <queries> for com.mojang.minecraftpe
        ├── java/com/alphalanucher/app/
        │   ├── GameVersion.java        enum: the two supported versions + matching
        │   ├── MinecraftDetector.java  install check, launch intent, app-info intent
        │   ├── Prefs.java              SharedPreferences wrapper
        │   ├── BaseActivity.java       slide/fade transitions
        │   ├── MainActivity.java       logo, banner, two cards, Play, Settings, About
        │   ├── SettingsActivity.java   toggles, re-check, app info, reset
        │   └── AboutActivity.java      what it does / cannot do / legal
        └── res/
            ├── layout/    activity_main, activity_settings, activity_about, item_version_card
            ├── drawable/  ic_logo (original pixel "A"), ic_launcher, glow + card/button shapes
            ├── anim/      screen transitions
            ├── color/     switch tints
            └── values/    colors, strings, styles
```

## Launch flow

```
Tap PLAY on a card
  └─ select that version (saved)
  └─ MinecraftDetector.check()
       ├─ not installed        → dialog: install it yourself, no files provided
       ├─ unsupported version  → dialog: only 0.14.3 / 0.15.10 supported
       ├─ other supported one  → dialog: cannot switch; uninstall/install steps
       └─ matches selection    → (optional confirm) → startActivity(launch intent)
```

## Key technical points

- **Package visibility:** Android 11+ hides other apps. The manifest declares
  `<queries><package android:name="com.mojang.minecraftpe"/></queries>` so the
  launcher can read that one app's version. No broad "see all apps" permission.
- **Version match:** `versionName` must equal the supported version, or start
  with it followed by `.`, `-` or a space. `0.15.10` matches `0.15.10.1` but not
  `0.15.1`.
- **No permissions requested.** No internet, no storage.
- **Design:** black/gray surfaces, blue glow built from stacked translucent
  layer-list shapes and a radial gradient, pulsing logo (toggle in Settings),
  60dp buttons, slide transitions.
- **Why plain Java and no AndroidX:** fewer downloads and a faster first build
  on a phone.
