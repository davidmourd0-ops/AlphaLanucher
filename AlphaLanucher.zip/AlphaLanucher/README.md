# AlphaLanucher

Unofficial Android launcher for Minecraft PE 0.14.3 and 0.15.10. It detects the
installed game and starts it. No game files included or downloaded.

- Architecture and limits: `ARCHITECTURE.md`
- How to build on a phone: `BUILD_ON_PHONE.md`

Status: source only, not yet compiled into an APK.
