package com.alphalanucher.app;

import android.os.Bundle;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends BaseActivity {

    private TextView tvDetected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        tvDetected = findViewById(R.id.tvDetected);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        Switch swConfirm = findViewById(R.id.swConfirm);
        swConfirm.setChecked(Prefs.confirmBeforeLaunch(this));
        swConfirm.setOnCheckedChangeListener((b, checked) -> Prefs.setConfirmBeforeLaunch(this, checked));

        Switch swGlow = findViewById(R.id.swGlow);
        swGlow.setChecked(Prefs.glowAnimation(this));
        swGlow.setOnCheckedChangeListener((b, checked) -> Prefs.setGlowAnimation(this, checked));

        findViewById(R.id.btnRecheck).setOnClickListener(v -> showDetected());

        findViewById(R.id.btnAppInfo).setOnClickListener(v -> {
            if (MinecraftDetector.check(this).installed) {
                MinecraftDetector.openAppInfo(this);
            } else {
                Toast.makeText(this, R.string.set_detected_none, Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.btnReset).setOnClickListener(v -> {
            Prefs.setSelected(this, GameVersion.V0_14_3);
            Toast.makeText(this, R.string.set_reset_done, Toast.LENGTH_SHORT).show();
        });

        showDetected();
    }

    @Override
    protected void onResume() {
        super.onResume();
        showDetected();
    }

    private void showDetected() {
        MinecraftDetector.Status s = MinecraftDetector.check(this);
        if (!s.installed) {
            tvDetected.setText(R.string.set_detected_none);
            return;
        }
        String text = getString(R.string.set_detected_version, s.versionName)
                + "\n"
                + getString(s.matched != null
                        ? R.string.set_detected_supported
                        : R.string.set_detected_unsupported);
        tvDetected.setText(text);
    }
}
