package com.alphalanucher.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;

/**
 * Finds out whether Minecraft PE is installed and which version it is.
 *
 * Both supported versions share the same package name, so Android can only
 * have ONE of them installed at a time. This class only READS that information.
 * It never modifies, downloads, or copies any game files.
 */
public final class MinecraftDetector {

    public static final String PACKAGE = "com.mojang.minecraftpe";

    private MinecraftDetector() {}

    /** Snapshot of what is installed right now. */
    public static final class Status {
        public final boolean installed;
        /** Raw versionName from Android, or null if not installed. */
        public final String versionName;
        /** The supported version that matches, or null (not installed, or unsupported version). */
        public final GameVersion matched;

        Status(boolean installed, String versionName, GameVersion matched) {
            this.installed = installed;
            this.versionName = versionName;
            this.matched = matched;
        }
    }

    @SuppressWarnings("deprecation")
    public static Status check(Context context) {
        try {
            PackageInfo info = context.getPackageManager().getPackageInfo(PACKAGE, 0);
            String name = info.versionName == null ? "?" : info.versionName;
            return new Status(true, name, GameVersion.fromInstalled(info.versionName));
        } catch (PackageManager.NameNotFoundException e) {
            return new Status(false, null, null);
        }
    }

    /** Intent that starts Minecraft PE, or null if it cannot be started. */
    public static Intent launchIntent(Context context) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(PACKAGE);
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        return intent;
    }

    /** Opens Android's own "App info" screen for Minecraft PE (where you can uninstall it). */
    public static void openAppInfo(Context context) {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.fromParts("package", PACKAGE, null));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
}
