package com.alphalanucher.app;

/**
 * The only Minecraft PE versions AlphaLanucher supports.
 * Adding a version here is not enough on its own: you would also need a card in the layout.
 */
public enum GameVersion {
    V0_14_3("0.14.3", R.string.card_014_subtitle),
    V0_15_10("0.15.10", R.string.card_015_subtitle);

    /** Version name as reported by Android (PackageInfo.versionName). */
    public final String versionName;
    public final int subtitleRes;

    GameVersion(String versionName, int subtitleRes) {
        this.versionName = versionName;
        this.subtitleRes = subtitleRes;
    }

    /** Display label, e.g. "MCPE 0.14.3". */
    public String label() {
        return "MCPE " + versionName;
    }

    /**
     * Returns the supported version that matches an installed versionName, or null.
     * "0.15.10" matches "0.15.10" and "0.15.10.1", but NOT "0.15.1".
     */
    public static GameVersion fromInstalled(String installedName) {
        if (installedName == null) return null;
        String name = installedName.trim();
        for (GameVersion v : values()) {
            if (name.equals(v.versionName)
                    || name.startsWith(v.versionName + ".")
                    || name.startsWith(v.versionName + "-")
                    || name.startsWith(v.versionName + " ")) {
                return v;
            }
        }
        return null;
    }

    /** Safe lookup for values saved in SharedPreferences. Falls back to the first version. */
    public static GameVersion fromKey(String key) {
        if (key != null) {
            for (GameVersion v : values()) {
                if (v.name().equals(key)) return v;
            }
        }
        return V0_14_3;
    }
}
