package com.alphalanucher.app;

import android.content.Context;
import android.content.SharedPreferences;

/** Tiny wrapper around SharedPreferences for launcher settings. */
public final class Prefs {

    private static final String FILE = "alphalanucher_prefs";
    private static final String KEY_SELECTED = "selected_version";
    private static final String KEY_CONFIRM = "confirm_launch";
    private static final String KEY_GLOW = "glow_animation";

    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static GameVersion getSelected(Context c) {
        return GameVersion.fromKey(sp(c).getString(KEY_SELECTED, null));
    }

    public static void setSelected(Context c, GameVersion v) {
        sp(c).edit().putString(KEY_SELECTED, v.name()).apply();
    }

    public static boolean confirmBeforeLaunch(Context c) {
        return sp(c).getBoolean(KEY_CONFIRM, false);
    }

    public static void setConfirmBeforeLaunch(Context c, boolean value) {
        sp(c).edit().putBoolean(KEY_CONFIRM, value).apply();
    }

    public static boolean glowAnimation(Context c) {
        return sp(c).getBoolean(KEY_GLOW, true);
    }

    public static void setGlowAnimation(Context c, boolean value) {
        sp(c).edit().putBoolean(KEY_GLOW, value).apply();
    }
}
