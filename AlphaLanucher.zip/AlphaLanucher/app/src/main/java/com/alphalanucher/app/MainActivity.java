package com.alphalanucher.app;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends BaseActivity {

    /** Holds the views of one version card. */
    private static final class Card {
        final GameVersion version;
        final View root;
        final TextView badge;
        final TextView state;
        final Button play;

        Card(GameVersion version, View root) {
            this.version = version;
            this.root = root;
            ((TextView) root.findViewById(R.id.tvVersion)).setText(version.label());
            ((TextView) root.findViewById(R.id.tvSubtitle)).setText(version.subtitleRes);
            this.badge = root.findViewById(R.id.tvBadge);
            this.state = root.findViewById(R.id.tvState);
            this.play = root.findViewById(R.id.btnPlay);
        }
    }

    private Card card014;
    private Card card015;
    private TextView tvSelected;
    private TextView tvBanner;
    private View logo;
    private View logoGlow;
    private Animator pulse;
    private GameVersion selected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvSelected = findViewById(R.id.tvSelected);
        tvBanner = findViewById(R.id.tvBanner);
        logo = findViewById(R.id.logo);
        logoGlow = findViewById(R.id.logoGlow);

        card014 = new Card(GameVersion.V0_14_3, findViewById(R.id.card014));
        card015 = new Card(GameVersion.V0_15_10, findViewById(R.id.card015));

        for (final Card card : new Card[]{card014, card015}) {
            // Tapping the card selects it; tapping PLAY selects it and tries to launch.
            card.root.setOnClickListener(v -> select(card.version));
            card.play.setOnClickListener(v -> {
                select(card.version);
                onPlay(card.version);
            });
        }

        findViewById(R.id.btnSettings).setOnClickListener(v -> openScreen(SettingsActivity.class));
        findViewById(R.id.btnAbout).setOnClickListener(v -> openScreen(AboutActivity.class));

        selected = Prefs.getSelected(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        selected = Prefs.getSelected(this);
        // Re-check every time we come back: the user may have just installed or removed Minecraft.
        refresh();
        updatePulse();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopPulse();
    }

    // ---------------------------------------------------------------- state

    private void select(GameVersion v) {
        selected = v;
        Prefs.setSelected(this, v);
        refresh();
    }

    /** Redraws the banner and both cards from the current install state. */
    private void refresh() {
        MinecraftDetector.Status s = MinecraftDetector.check(this);

        tvSelected.setText(selected.label());
        tvBanner.setText(bannerText(s));

        bindCard(card014, s);
        bindCard(card015, s);
    }

    private String bannerText(MinecraftDetector.Status s) {
        if (!s.installed) return getString(R.string.banner_not_installed);
        if (s.matched == null) return getString(R.string.banner_unsupported, s.versionName);
        if (s.matched == selected) return getString(R.string.banner_match, s.versionName);
        return getString(R.string.banner_mismatch, s.versionName);
    }

    private void bindCard(Card card, MinecraftDetector.Status s) {
        boolean isSelected = card.version == selected;
        card.root.setBackgroundResource(isSelected ? R.drawable.bg_card_selected : R.drawable.bg_card);
        card.badge.setVisibility(isSelected ? View.VISIBLE : View.INVISIBLE);

        if (!s.installed) {
            card.state.setText(R.string.state_not_installed);
            card.state.setTextColor(getColor(R.color.warn));
        } else if (s.matched == card.version) {
            card.state.setText(R.string.state_ready);
            card.state.setTextColor(getColor(R.color.ok));
        } else if (s.matched != null) {
            card.state.setText(getString(R.string.state_other_supported, s.versionName));
            card.state.setTextColor(getColor(R.color.muted));
        } else {
            card.state.setText(getString(R.string.state_unsupported, s.versionName));
            card.state.setTextColor(getColor(R.color.bad));
        }
    }

    // ---------------------------------------------------------------- launching

    private void onPlay(GameVersion wanted) {
        MinecraftDetector.Status s = MinecraftDetector.check(this);

        if (!s.installed) {
            showInfo(R.string.dlg_not_installed_title,
                    getString(R.string.dlg_not_installed_msg, wanted.versionName), false);
        } else if (s.matched == null) {
            showInfo(R.string.dlg_unsupported_title,
                    getString(R.string.dlg_unsupported_msg, s.versionName), true);
        } else if (s.matched != wanted) {
            // The launcher cannot swap versions: both share one package name.
            showInfo(R.string.dlg_mismatch_title,
                    getString(R.string.dlg_mismatch_msg, wanted.versionName, s.versionName), true);
        } else if (Prefs.confirmBeforeLaunch(this)) {
            new AlertDialog.Builder(this, R.style.AlphaDialog)
                    .setTitle(getString(R.string.dlg_confirm_title, wanted.versionName))
                    .setMessage(R.string.dlg_confirm_msg)
                    .setNegativeButton(R.string.dlg_cancel, null)
                    .setPositiveButton(R.string.dlg_launch, (d, w) -> launchGame())
                    .show();
        } else {
            launchGame();
        }
    }

    private void launchGame() {
        android.content.Intent intent = MinecraftDetector.launchIntent(this);
        if (intent == null) {
            Toast.makeText(this, R.string.toast_cannot_launch, Toast.LENGTH_LONG).show();
            return;
        }
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, R.string.toast_cannot_launch, Toast.LENGTH_LONG).show();
        }
    }

    private void showInfo(int titleRes, String message, boolean offerAppInfo) {
        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.AlphaDialog)
                .setTitle(titleRes)
                .setMessage(message)
                .setPositiveButton(R.string.dlg_ok, null);
        if (offerAppInfo) {
            b.setNeutralButton(R.string.dlg_open_info,
                    (d, w) -> MinecraftDetector.openAppInfo(this));
        }
        b.show();
    }

    // ---------------------------------------------------------------- logo glow

    private void updatePulse() {
        stopPulse();
        if (!Prefs.glowAnimation(this)) return;

        ObjectAnimator glow = ObjectAnimator.ofPropertyValuesHolder(logoGlow,
                PropertyValuesHolder.ofFloat(View.ALPHA, 0.55f, 1f),
                PropertyValuesHolder.ofFloat(View.SCALE_X, 0.92f, 1.08f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.92f, 1.08f));
        ObjectAnimator mark = ObjectAnimator.ofPropertyValuesHolder(logo,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.04f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.04f));
        for (ObjectAnimator a : new ObjectAnimator[]{glow, mark}) {
            a.setDuration(1800);
            a.setRepeatCount(ObjectAnimator.INFINITE);
            a.setRepeatMode(ObjectAnimator.REVERSE);
            a.setInterpolator(new AccelerateDecelerateInterpolator());
        }
        AnimatorSet set = new AnimatorSet();
        set.playTogether(glow, mark);
        set.start();
        pulse = set;
    }

    private void stopPulse() {
        if (pulse != null) {
            pulse.cancel();
            pulse = null;
        }
        logoGlow.setAlpha(1f);
        logoGlow.setScaleX(1f);
        logoGlow.setScaleY(1f);
        logo.setScaleX(1f);
        logo.setScaleY(1f);
    }
}
