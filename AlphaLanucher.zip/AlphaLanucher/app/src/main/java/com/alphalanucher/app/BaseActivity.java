package com.alphalanucher.app;

import android.app.Activity;
import android.content.Intent;

/** Shared smooth slide/fade transitions between screens. */
@SuppressWarnings("deprecation")
public abstract class BaseActivity extends Activity {

    /** Opens another screen with a slide-in animation. */
    protected void openScreen(Class<? extends Activity> target) {
        startActivity(new Intent(this, target));
        overridePendingTransition(R.anim.slide_in_right, R.anim.fade_out_left);
    }

    @Override
    public void finish() {
        super.finish();
        // Slide back only on sub-screens, not when leaving the main screen.
        if (!isTaskRoot()) {
            overridePendingTransition(R.anim.slide_in_left, R.anim.fade_out_right);
        }
    }
}
